package com.monalisa.employeelogin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeLoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeLoginApplication.class, args);
	}

}
